create function gettoptrainingsbyrating(number integer)
    returns TABLE(training_id integer, training_name character varying, training_description text, training_uses integer, training_rate integer)
    language plpgsql
as
$$
            BEGIN
                IF number = 0 then
                return query (select training.training_id, training.name, training.description, training_rate.number_uses, training_rate.all_time_rate_difference from training
                    join training_rate on training.training_id = training_rate.fk_training_id order by training_rate.all_time_rate_difference desc);
                ELSE
                return query (select training.training_id, training.name, training.description, training_rate.number_uses, training_rate.all_time_rate_difference from training
                    join training_rate on training.training_id = training_rate.fk_training_id order by training_rate.all_time_rate_difference desc limit number);
                END IF;
                EXCEPTION
                    WHEN duplicate_function THEN
                    NULL;
            END;
            $$;

alter function gettoptrainingsbyrating(integer) owner to postgres;

