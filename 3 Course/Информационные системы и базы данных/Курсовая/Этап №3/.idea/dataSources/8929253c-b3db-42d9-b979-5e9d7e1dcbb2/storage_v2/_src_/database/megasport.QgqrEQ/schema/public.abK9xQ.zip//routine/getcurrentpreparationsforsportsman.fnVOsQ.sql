create function getcurrentpreparationsforsportsman(sportsmanid integer)
    returns TABLE(sportsman_id integer, sportsman_full_name integer, sportsman_sex character varying, sportsman_date_of_birth date, sportsman_rate double precision, preparation_id integer)
    language plpgsql
as
$$
        BEGIN
            return query (select sportsman.sportsman_id, sportsman.full_name, sportsman.sex, sportsman.date_of_birth, sportsman_sport.rate, preparation.preparation_id from sportsman
                join sportsman_sport on sportsman.sportsman_id = sportsman_sport.fk_sportsman_id and sportsman.sportsman_id = sportsmanId
                join preparation on sportsman_sport.fk_preparation_id = preparation.preparation_id
                order by sportsman_sport.rate desc);
            EXCEPTION
                WHEN duplicate_function THEN
                NULL;
        END;
        $$;

alter function getcurrentpreparationsforsportsman(integer) owner to postgres;

