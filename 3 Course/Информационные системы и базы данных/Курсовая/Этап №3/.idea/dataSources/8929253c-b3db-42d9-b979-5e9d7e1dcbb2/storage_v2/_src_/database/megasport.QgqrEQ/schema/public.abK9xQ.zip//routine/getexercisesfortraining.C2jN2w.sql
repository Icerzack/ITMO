create function getexercisesfortraining(train_id integer)
    returns TABLE(training_id integer, training_name character varying, training_description text, exercise_id integer, exercise_name character varying, exercise_description text)
    language plpgsql
as
$$
            BEGIN
                return query (select training.training_id, training.name, training.description, exercise.exercise_id, exercise.name, exercise.description from training
                    join training_exercise on training.training_id = training_exercise.fk_training_id
                    join exercise on training_exercise.fk_exercise_id = exercise.exercise_id
                    WHERE training.training_id = train_id);
                EXCEPTION
                    WHEN duplicate_function THEN
                    NULL;
            END;
            $$;

alter function getexercisesfortraining(integer) owner to postgres;

