create function getinfoaboutpreparation(prep_id integer)
    returns TABLE(preparation_id integer, training_id integer, training_name character varying, training_description text, baa_id integer, baa_name character varying, baa_desc text, preparation_rating double precision)
    language plpgsql
as
$$
            BEGIN
                return query (select preparation.preparation_id, training.training_id, training.name, training.description, baa.baa_id, baa.name, baa.description, preparation_rate.effectiveness from preparation
                    join training on preparation.fk_training_id = training.training_id
                    join baa on preparation.fk_baa_id = baa.baa_id
                    join preparation_rate on preparation.preparation_id = preparation_rate.fk_preparation_id
                    where preparation.preparation_id = prep_id);
                EXCEPTION
                    WHEN duplicate_function THEN
                    NULL;
            END;
            $$;

alter function getinfoaboutpreparation(integer) owner to postgres;

